# AMSTRAD CONSOLA

Este software es parte de el SDK CPCReady, sin el su funcionamiento no es correcto.

### Descripcion

Consola con una interface similar a la de amstrad para Visual Studio Code.